<?php

namespace App\Providers;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Ang Angular nagpaabot ug diretso nga JSON (walay "data" wrapper)
        JsonResource::withoutWrapping();
    }
}